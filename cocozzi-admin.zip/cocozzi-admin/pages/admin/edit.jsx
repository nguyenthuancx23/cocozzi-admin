import React from 'react'

const edit = () => {
  return (
    <div>edit</div>
  )
}

export default edit